#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define MAX_ROWS 100
#define MAX_COLS 100
#define MAX_MATRIX 10

typedef struct {
    int rows;
    int cols;
    int** elements;
} Matrix;

typedef struct {
    Matrix* matrix1;
    Matrix* matrix2;
    Matrix* result;
    int startRow;
    int endRow;
    char operation;
} ThreadData;

Matrix stack[MAX_MATRIX];
int stackTop = -1;

char operatorStack[MAX_MATRIX];
int operatorStackTop = -1;

pthread_mutex_t stackMutex = PTHREAD_MUTEX_INITIALIZER;

// Function to initialize a matrix
void initializeMatrix(Matrix* matrix, int rows, int cols) {
    matrix->rows = rows;
    matrix->cols = cols;

    matrix->elements = (int**)malloc(rows * sizeof(int*));
    for (int i = 0; i < rows; ++i) {
        matrix->elements[i] = (int*)malloc(cols * sizeof(int));
    }
}

// Function to set matrix data from input
void setMatrixData(Matrix* matrix, FILE* input) {
    for (int i = 0; i < matrix->rows; ++i) {
        for (int j = 0; j < matrix->cols; ++j) {
            fscanf(input, "%d", &matrix->elements[i][j]);
        }
    }
}

// Function to push a matrix onto the stack
void pushMatrix(Matrix matrix) {
    pthread_mutex_lock(&stackMutex);
    stack[++stackTop] = matrix;
    pthread_mutex_unlock(&stackMutex);
}

// Function to pop a matrix from the stack
Matrix popMatrix() {
    pthread_mutex_lock(&stackMutex);
    Matrix matrix = stack[stackTop--];
    pthread_mutex_unlock(&stackMutex);
    return matrix;
}

// Function to push an operator onto the stack
void pushOperator(char operator) {
    operatorStack[++operatorStackTop] = operator;
}

// Function to pop an operator from the stack
char popOperator() {
    return operatorStack[operatorStackTop--];
}

// Function to add two matrices
void addMatrices(Matrix* matrix1, Matrix* matrix2, Matrix* result) {
    for (int i = 0; i < result->rows; ++i) {
        for (int j = 0; j < result->cols; ++j) {
            result->elements[i][j] = matrix1->elements[i][j] + matrix2->elements[i][j];
        }
    }
}

// Function to subtract two matrices
void subtractMatrices(Matrix* matrix1, Matrix* matrix2, Matrix* result) {
    for (int i = 0; i < result->rows; ++i) {
        for (int j = 0; j < result->cols; ++j) {
            result->elements[i][j] = matrix1->elements[i][j] - matrix2->elements[i][j];
        }
    }
}

// Function to multiply two matrices (worker function for each thread)
void* multiplyMatrices(void* arg) {
    ThreadData* data = (ThreadData*)arg;

    Matrix tempResult;
    initializeMatrix(&tempResult, data->result->rows, data->result->cols);

    switch (data->operation) {
        case '+':
            addMatrices(data->matrix1, data->matrix2, &tempResult);
            break;
        case '-':
            subtractMatrices(data->matrix1, data->matrix2, &tempResult);
            break;
        case '*':
            for (int i = data->startRow; i < data->endRow; ++i) {
                for (int j = 0; j < data->matrix2->cols; ++j) {
                    tempResult.elements[i][j] = 0;
                    for (int k = 0; k < data->matrix1->cols; ++k) {
                        tempResult.elements[i][j] += data->matrix1->elements[i][k] * data->matrix2->elements[k][j];
                    }
                }
            }
            break;
        default:
            // Handle unknown operation
            fprintf(stderr, "Error: Unknown operation '%c'\n", data->operation);
            break;
    }

    // Copy the temporary result to the actual result matrix
    for (int i = 0; i < tempResult.rows; ++i) {
        for (int j = 0; j < tempResult.cols; ++j) {
            data->result->elements[i][j] = tempResult.elements[i][j];
        }
    }

    // Free the memory allocated for the temporary result matrix
    for (int i = 0; i < tempResult.rows; ++i) {
        free(tempResult.elements[i]);
    }
    free(tempResult.elements);

    return NULL;
}

// Function to evaluate the expression
void evaluateExpression(FILE* input) {
    char operation[10];
    fscanf(input, "%s", operation);

    int rows, cols;
    fscanf(input, "%d %d", &rows, &cols);

    Matrix result;
    initializeMatrix(&result, rows, cols);

    while (1) {
        char symbol;
        if (fscanf(input, " %c", &symbol) == EOF) {
            break;
        }

        if (symbol == '+' || symbol == '-') {
            pushOperator(symbol);
        }
        else if (symbol == '*') {
            Matrix matrix1 = popMatrix();
            Matrix matrix2;
            initializeMatrix(&matrix2, rows, cols);
            setMatrixData(&matrix2, input);

            ThreadData threadData;
            threadData.matrix1 = &matrix1;
            threadData.matrix2 = &matrix2;
            threadData.result = &result;
            threadData.startRow = 0;
            threadData.endRow = rows;
            threadData.operation = symbol;

            pthread_t thread;
            pthread_create(&thread, NULL, multiplyMatrices, (void*)&threadData);
            pthread_join(thread, NULL);
        }
        else if (symbol == '\n') {
            break;
        }
        else {
            initializeMatrix(&stack[++stackTop], rows, cols);
            setMatrixData(&stack[stackTop], input);

            if (popOperator() == '*') {
                Matrix matrix1 = popMatrix();
                Matrix matrix2 = popMatrix();

                ThreadData threadData;
                threadData.matrix1 = &matrix1;
                threadData.matrix2 = &matrix2;
                threadData.result = &result;
                threadData.startRow = 0;
                threadData.endRow = rows;
                threadData.operation = '*';

                pthread_t thread;
                pthread_create(&thread, NULL, multiplyMatrices, (void*)&threadData);
                pthread_join(thread, NULL);
            }
        }
    }

    // Output the result matrix
    for (int i = 0; i < result.rows; ++i) {
        for (int j = 0; j < result.cols; ++j) {
            printf("%d\t", result.elements[i][j]);
        }
        printf("\n");
    }
}

int main() {
    // Test your evaluateExpression function
    FILE* input = fopen("matrix11.txt", "r");
    if (input == NULL) {
        perror("Error opening file");
        return 1;
    }

    evaluateExpression(input);

    // Close file and free allocated memory if necessary
    fclose(input);

    for (int i = 0; i <= stackTop; ++i) {
        free(stack[i].elements);
    }

    return 0;
}
